// // var a = [
// //     "Hydrogen",
// //     "Helium",
// //     "Lithium",
// //     "Beryl­lium"
// // ];
// //
// // var a2 = a.map(function(s){ return s.length });
// //
// // var a3 = a.map( s => s.length );
// //
// // console.log(a);
// // console.log(a2);
// // console.log(a3);
// // var original = Promise.resolve(false);
// // console.log(original);
// // var cast = Promise.resolve(original);
// // cast.then(function(v) {
// //     console.log(v); // true
// // });
// //
// // var promise = Promise.resolve(3);
// // Promise.all([true, false, 1, 2, promise])
// //     .then(values => {
// //     console.log(values); // [true, 3]
// // });
// //
// //
// // Promise.all([1, 2, 3]).then(values => {console.log(values)});
// // Promise.all([1, 2, 3]).then(function (value) {console.log(value)});
// // //same as last line.
//
// // var q1 = function() {
// //     return new Promise(function (fulfill, reject){
// //             if(false){
// //                 fulfill(console.log('q1 done in fulfill'));
// //             }else{
// //                 reject(console.log('q1 done in reject'))
// //             }
// //
// //     });
// // };
// // var q3 = function(){
// //     console.log("q3 done");
// // }
// // q1();
// //
// // q1().then(q3);
//
//
// // var request = require('request');
// // request('http://www.google.com', function (error, response, body) {
// //     if (!error && response.statusCode == 200) {
// //         console.log(body) // 打印google首页
// //     }
// // })
//
// // var text = '[{"date":"20-06 11:23:01","_id":"51c2759fa828f0920b000005"}, {"name" : "yuxin shi"}]';
// // var arr = JSON.parse( text );
// //
// // console.log('Date:' + arr[0].date );
// // console.log('nanme: ' + arr[1].name);
//
// const Account = require('./configs/account');
// const Request = require('request');
// const Promise = require('bluebird');
// const Utils = require('./helpers/my_utils');
//
//
// function crawl_contributors(repo_full_name, callback) {
//
//
//     var request = require("request");
//
//     var url = "https://api.github.com/repos/twbs/bootstrap/stats/contributors";
//     var return_list = [];
//     // console.log("return_list out request: " + return_list);
//
//     Request({
//         url: url,
//         json: true,
//         method: 'GET', //Specify the method
//         headers: { //Define headers
//             'User-Agent': 'request'
//         },
//         auth: { //HTTP Authentication
//             user: 'dalianmao22233',
//             pass: 'Aa1313250!'
//         },
//     }, function (error, response, body) {
//         if (!error && response.statusCode === 200) {
//             if (body == null || body.length == 0) {
//                 // error("body is empty!");
//                 return callback(error || {statusCode: response.statusCodes});
//             }
//
//
//             // console.log("body length!!!!!!!!:" + body.length);
//             // console.log(body[0].total) // Print the json response
//             // console.log(body[0].author.login);
//             // for (var i = 0; i < body.length; i++) {
//             //     return_list.push(body[i].total.toString() + "," + body[i].author.login.toString());
//             // }
//
//             return_list.push(body[0].total);
//             console.log("return_list in request: " + return_list);
//             callback(null, "return_list: " + return_list);
//             // return return_list;
//
//         }
//         else {
//             console.log("err");
//         }
//     })
//
//
// }
//
// crawl_contributors("hello", function(error, res) {
//     if(error) {
//         console.log(error);
//     }
//     else{
//         console.log(res);
//     }
// })

// var a = {"name" : "yuxin", "age" : "12"};
// a["sex"] = [{"naem1" : "123"}, {"name2" : "456"}];
// console.log(a);


// fn should return an object like
// {
//   done: false,
//   value: foo
// }
// var Promise = require('bluebird');
// var i = 0;
//
// var counter = Promise.method(function(){
//     return i++;
// })
//
// function getAll(max, results){
//     var results = results || [];
//     return counter().then(function(result){
//         results.push(result);
//         return (result < max) ? getAll(max, results) : results
//     })
// }
//
// getAll(10).then(function(data){
//     console.log(data);
// })

var variables = [1,2,3,4,5];
Promise.all(
    variables.map(function ( i) {
        return new Promise(function (resolve, reject) {
            console.log("file-" + i + ".txt");
        });
    })
)
    .then(function () {
        // Files have been written
    })
    .catch(function (err) {
        // Some errors occured
    });