module.exports = {
    username: 'dalianmao22233',
    password: 'Aa1313250!',
    firebase_secrets: 'ZdCmtODlYiAgo5Tr5MioruBYF29sPo7X4iRZq97e',
    // firebase_url: '《https://firstproject-a737a.firebaseapp.com》'
    firebase_url: 'https://firstproject-a737a.firebaseio.com'
}