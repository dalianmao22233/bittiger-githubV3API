// var a = [
//     "Hydrogen",
//     "Helium",
//     "Lithium",
//     "Beryl­lium"
// ];
//
// var a2 = a.map(function(s){ return s.length });
//
// var a3 = a.map( s => s.length );
//
// console.log(a);
// console.log(a2);
// console.log(a3);
// var original = Promise.resolve(false);
// console.log(original);
// var cast = Promise.resolve(original);
// cast.then(function(v) {
//     console.log(v); // true
// });
//
// var promise = Promise.resolve(3);
// Promise.all([true, false, 1, 2, promise])
//     .then(values => {
//     console.log(values); // [true, 3]
// });
//
//
// Promise.all([1, 2, 3]).then(values => {console.log(values)});
// Promise.all([1, 2, 3]).then(function (value) {console.log(value)});
// //same as last line.

// var q1 = function() {
//     return new Promise(function (fulfill, reject){
//             if(false){
//                 fulfill(console.log('q1 done in fulfill'));
//             }else{
//                 reject(console.log('q1 done in reject'))
//             }
//
//     });
// };
// var q3 = function(){
//     console.log("q3 done");
// }
// q1();
//
// q1().then(q3);


var request = require('request');
request('http://www.google.com', function (error, response, body) {
    if (!error && response.statusCode == 200) {
        console.log(body) // 打印google首页
    }
})