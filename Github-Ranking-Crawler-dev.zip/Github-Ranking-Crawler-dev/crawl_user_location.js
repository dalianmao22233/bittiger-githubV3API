/**
 * Created by dalianmao22233 on 7/11/16.
 */
const Account = require('./configs/account');
const Request = require('request');
const Promise = require('bluebird');
const Utils = require('./helpers/my_utils');


function crawl_user_locations(url) {
    return new Promise(function (fulfill, reject) {
        var location_info = null;
        console.log(url);
        var new_info = [];
        var funcs = Promise.resolve(makeRequest(make_option(url)));
        funcs
            .catch(function (err) {
                console.log(err);
            })
            .finally(function () {
                // console.log(JSON.stringify(location_info))
                fulfill(new_info);
            })
        function makeRequest(option) {
            return new Promise(function (fulfill, reject) {
                Request(option, function (error, response, body) {
                    if (error) {
                        reject(error);
                    } else if (body == null || body.length == 0) {
                        reject('page empty in craw_user_locaiton.js');
                    } else {
                        // console.log("body: " + JSON.stringify(body["location"]));
                        //
                        location_info = {
                            'location1': body["location"]
                        }
                        new_info.push(location_info);

                        fulfill(body);
                    }
                })
            })
        }

    });

}
function make_option(url) {
    return {
        url: url,// URL to hit
        method: 'GET', //Specify the method
        headers: { //Define headers
            'User-Agent': 'request'
        },
        auth: { //HTTP Authentication
            user: 'dalianmao22233',
            pass: 'Aa1313250!'
        },
        json: true

    };
}
function iterator(f) {
    return f()
}
exports.crawl_user_locations = crawl_user_locations;
